package main

import pkg "github.com/gregmus2/ants-pkg"

type Anthill struct {
	Pos      *pkg.Pos
	BirthPos *pkg.Pos
}
