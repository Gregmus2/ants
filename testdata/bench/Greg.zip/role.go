package example

type Role uint8

const (
	explorer Role = iota
	defender
	attacker
)
