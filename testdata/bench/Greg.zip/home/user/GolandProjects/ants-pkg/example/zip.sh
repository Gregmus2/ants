rm Greg.zip
zip -r -9 Greg.zip /home/user/GolandProjects/ants-pkg/example/*
cp /home/user/GolandProjects/ants-pkg/example/Greg.zip /home/user/go/src/ants/testdata