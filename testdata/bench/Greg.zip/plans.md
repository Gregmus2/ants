* obsolete fields in area 
* teams for attack